"use strict";

var keyMirror = require('keymirror');

module.exports = keyMirror ({
  INITIALISE: null,
  CREATE_AUTHOR: null,
  UPDATE_AUTHOR: null,
  DELETE_AUTHOR: null
});
