/*
* Facebook
* AppDispatcher
*
* A singleton that operates as the control hub for application updates.
*
*/

var Dispatcher = require('flux').Dispatcher;

module.exports = new Dispatcher();
